title: Elasticsearch学习（二）图解 ES的windows搭建及测试（Helloworld）
date: '2019-11-25 01:52:48'
updated: '2019-11-25 01:52:48'
tags: [原创, ES]
permalink: /articles/2019/11/25/1574617968802.html
---
![](https://img.hacpai.com/bing/20180825.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 这篇文章讲一下 ES在Windows上面的搭建及测试. 后续更新centos环境下的安装

**一. Java环境变量配置**

1. 下载JDK, 末尾附下载链接
2. 配置如下图
![B8MCD2K7118IZ3GK.png](https://img.hacpai.com/file/2019/11/B8MCD2K7118IZ3GK-b9b991d5.png)

3. 检验是否成功如下图
![PX57SIYZEG483E7F08.png](https://img.hacpai.com/file/2019/11/PX57SIYZEG483E7F08-1253428d.png)

**二. window版本ES下载**
1. 登录官网分别下载 Elasticsearch和Kibana，版本选择一般自hai就用最新的 [ES官网]
![FZPSJ9UZF8S6R1N1JO.png](https://img.hacpai.com/file/2019/11/FZPSJ9UZF8S6R1N1JO-94e0411d.png)
2. 目前最新的版本是，直接选择 WINDOWS sha asc  [点我也行](https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-7.4.2-windows-x86_64.zip)  就OK.
![0599193138AE44ecBB5781021621E60E.png](https://img.hacpai.com/file/2019/11/0599193138AE44ecBB5781021621E60E-a62b6d8c.png)
3.  下载完成之后，解压文件

**三. 文件目录介绍**
```
1) ../bin/  启动脚本
2) ../config/  配置文件
3) ../data/  索引数据目录
4) ../lib/  相关类库Jar包
5) ../logs/  日志目录
6) ../modules/  功能模块
7) ../plugins/  插件
8)  log4j2.properties  日志配置文件  
9)  jvm.options  java虚拟机的配置  
10)  elasticsearch.yml  es的配置文件
```

**四.  启动Elasticsearch**
* 第一种方式
```
1. 打开cmd命令行窗口  
2. 进入解压文件目录，bin目录
3. elasticsearch -d
```

* 第二种方式
```
1. 进入解压目录bin文件夹下，执行elasticsearch.bat文件
```
* 第三种方式
1. 做成service. 每次启动服务就好了

启动成功如图: 
![6751305F2F0A445e82C6794C583B50C8.png](https://img.hacpai.com/file/2019/11/6751305F2F0A445e82C6794C583B50C8-14c47b1c.png)

**五.  访问http://localhost:9200/**
如图出现下面的文档信息， 安装ES成功. (＾－＾)V
![5A51C0C7F287401187446563431D03D2.png](https://img.hacpai.com/file/2019/11/5A51C0C7F287401187446563431D03D2-4f79f8d6.png)

**六.  启动Kibana**
1. 直接进入bin路径，或者参照ES命令行方式，启动
![B52CB8AE6C6E4742BC1E9DF5D7A502B4.png](https://img.hacpai.com/file/2019/11/B52CB8AE6C6E4742BC1E9DF5D7A502B4-67e0d537.png)

2. 启动可能会有点慢， 然后需要网络等授权时，360之类的会弹窗，直接全部允许就好了, 启动成功如图
![image.png](https://img.hacpai.com/file/2019/11/image-33dc9292.png)

3. 浏览器地址访问 [http://localhost:5601](http://localhost:5601) 进入下图, 点击NO 
![image.png](https://img.hacpai.com/file/2019/11/image-721a421b.png)

4. 拖动，滚动条，点击“console” 进入到控制台
![image.png](https://img.hacpai.com/file/2019/11/image-48564ac2.png)

5.  点击运行，即可解锁查看HelloWorld 文档内容.
![image.png](https://img.hacpai.com/file/2019/11/image-43dc4cd8.png)

6. 至此，大功告成哈哈哈哈哈.. 但是还早着呢, 一些概念，核心内容. 下周再说再说..告辞啦





附JDK下载路径
链接：[https://pan.baidu.com/s/1Y6yN3C04gwFKCSUrc1pzlw ](https://pan.baidu.com/s/1Y6yN3C04gwFKCSUrc1pzlw )
提取码：niib 
复制这段内容后打开百度网盘手机App，操作更方便哦

每次，迷迷糊糊的时候都有你在，真好~❤


