title: SpringCloud微服务Feign服务ReadTimeout问题处理
date: '2019-12-02 00:26:34'
updated: '2019-12-02 00:27:34'
tags: [原创, BUG, SpringCloud]
permalink: /articles/2019/12/02/1575217593907.html
---
![](https://img.hacpai.com/bing/20190622.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

吐槽一下，这个项目架构..搭建的就很灵性，啥东西都没有设置好. 
没人管 基本上，

然后找了资料解决了下面的超时问题，还有很多问题需要继续抽空去弄下，
每次任务都安排的很多，不给时间，然后又么有需求文档参考，就弄得很不爽. 
- ---- 
下面是问题处理.

错误提示： timed-out and no fallback available：

```
这个错误基本是出现在Hystrix熔断器，熔断器的作用是判断该服务能不能通，如果通了就不管了，调用在指定
时间内超时时，就会通过熔断器进行错误返回。

一般设置如下配置的其中一个即可：

1. 把时间设长

我设置成5秒

hystrix.command.default.execution.isolation.thread.timeoutInMilliseconds=5000 

2. 设置hystrix超时属性为关闭

hystrix.command.default.execution.timeout.enabled=false 

3. 禁用feign的hystrix， feign 客户端调用的时候这个有时候很坑..没办法有些接口从一开始数据库设计就有问
题，导致太慢了.. 还有一些中间件没有安排上， 哎好像去大厂看看大佬们是咋弄的呀.. 

feign.hystrix.enabled: false 
failed and no fallback available：

而通过上面设置只是针对熔断器的错误关闭，并不能解决根本问题，比如Feign客户端调用远程服务时，默认为
8秒超时时间，如果在规定时间内没有返回，同样会跳转到熔断器进行处理。即使关闭了熔断器的错误，但是总
的错误处理还会是有这个问题出现。

那么要解决根本问题，就要从请求超时时间入手，因为有些服务可能存在调用时间长的问题，所以直接配置：

ribbon.ReadTimeout=60000
ribbon.ConnectTimeout=60000

这些才是真正解决请求超时的问题，如果不设置这个，被调用接口很慢时，会出现Read Timeout on Request。
而针对调用失败重试的次数也可以设置：

ribbon.maxAutoRetries=0
```
