title: HandlerMethodReturnValueHandler处理全局返回值引起的BUG.
date: '2019-12-05 10:54:02'
updated: '2019-12-05 10:55:52'
tags: [原创, BUG]
permalink: /articles/2019/12/05/1575514442033.html
---
![](https://img.hacpai.com/bing/20190330.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

因为近期在做导出这块，然后也遇到了一些坑.. 
由POI引起来的导出的坑￣へ￣

先说一下，这个全局返回值处理的时候遇到的坑. 
就我Controller这边，没有按照他的Result格式返回， 是直接返回生成的Excel流到response
outputstream中. 
就返回一个异常. 
## Could not find acceptable representation

这个是因为我controller返回的是void，没有按照他同一个Result<T>来返回，导致 HandlerObj.target的时候，出错了. 这里修改的话，需要将这里拦截的时候， 盘点，如下代码， 如果 returnValue为空就进行退出.了， 不进行他的target方法. 

```
public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer,
                                  NativeWebRequest webRequest) throws Exception {
        Object resultInfo = returnValue;
        if (resultInfo == null) {   // 如果返回值为空. 则直接跳走不要继续辽... 就这里的坑. 
            return;
        }
        //不处理来自Api的请求
        if (!returnType.hasMethodAnnotation(ApiMethodMapping.class)) {
            /**** 处理app请求 ****/
            //注解@ResultKey的返回值
            if (returnType.hasMethodAnnotation(ResultKey.class)) {
                ResultKey resultKey = returnType.getMethodAnnotation(ResultKey.class);
                if (StringUtils.isNotBlank(resultKey.value())) {
                    HashMap returnData = new HashMap();
                    returnData.put(resultKey.value(), returnValue);
                    resultInfo = returnData;
                }
            }
            //处理非Result返回
            if (!returnType.getParameterType().isAssignableFrom(Result.class)) {
                resultInfo = Result.ok(resultInfo);
            }
        }
        target.handleReturnValue(resultInfo, returnType, mavContainer, webRequest);
    }
```


啊啊啊啊啊啊啊啊啊... 

遇到这个我知道是切面的问题，可以有好多AOP切面. 跟的肉疼..


改BUG跟捉鬼一样.. 
(*￣︶￣)
